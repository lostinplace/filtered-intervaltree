This is a *triumph*

I'm making a note here: *huge success*

